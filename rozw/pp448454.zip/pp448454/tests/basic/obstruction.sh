set -ex
./run_test 0.4 7 examples_build/obstruction
