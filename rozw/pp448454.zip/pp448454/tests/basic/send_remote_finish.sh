#!/bin/bash
set -e
./run_test 4s 10 examples_build/send_remote_finish
