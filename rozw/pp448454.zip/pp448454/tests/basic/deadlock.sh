set -ex
./run_test 1s 4 examples_build/deadlock
