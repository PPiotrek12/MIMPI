set -x
./run_test 0.4 3 examples_build/reduction
