set -x
./run_test 0.4 5 examples_build/bad_rank
