
for (( i=0; i<1000000; i++ ))
do
    ./run_test 0.4s 16 ./examples_build/all_my_file_desc

done